from Crypto.Util.number import *

message = "REDACTED"

def generate_big_keys(x : int) -> list:
    return [ getPrime(69) for _ in range(x) ]

def encrypt(message : str) -> list:
    x = len(message)
    keys = generate_big_keys(x)
    c = []
    for i,key in zip(range(1, x*x + 1, x),keys):
        c.append([((-1)*j) for j in range(i,i+x)])

    for i,k in zip(range(x), keys):
        for j in range(x):
            if(i == j):
                c[i][j] = ((-1) * ord(message[i]) ) % k
            else:
                c[i][j] = c[i][j] % k
    return c

encrypted_message = encrypt(message)

with open('out.txt','w') as f:
    f.write(str(encrypted_message))
